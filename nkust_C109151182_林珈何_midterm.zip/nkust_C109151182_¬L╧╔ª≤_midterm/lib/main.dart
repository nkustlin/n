import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';

final player=AudioPlayer();

void main() => runApp(MyApp());

class MyApp extends StatefulWidget {
  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {

  final tabs=[
    Center(child: screen1()),
    Center(child: screen2()),
    Center(child: screen3()),
    Center(child: screen4()),
  ];

  int _currentindex=0;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(title: Text('Midterm'),),
        body: tabs[_currentindex],
        bottomNavigationBar: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          backgroundColor: Colors.blue,
          selectedItemColor: Colors.white,
          selectedFontSize: 18.0,
          unselectedFontSize: 14.0,
          iconSize: 30.0,
          currentIndex: _currentindex,
          items: [
            BottomNavigationBarItem(icon: Icon(Icons.home),
                                    label: 'Home',
                                    ),
            BottomNavigationBarItem(icon: Icon(Icons.access_alarm),
                                    label: 'Alarm',
                                    ),
            BottomNavigationBarItem(icon: Icon(Icons.business),
                                    label: 'Business',
                                    ),
            BottomNavigationBarItem(icon: Icon(Icons.school),
                                    label: 'School',
                                    ),
          ],
          onTap: (index) { setState(() {
                                       _currentindex=index;
                                       if (index!=0) {
                                         player.stop();
                                       }
                         });
        },
      ),
      ),
    );
  }
}

class screen1 extends StatelessWidget {

  final String s1='資工系C109151182林珈何'
 "\n家庭背景\n我的名字叫林珈何，家中經營小吃店，小看著爸爸媽媽做生意，忙碌辛苦的身影就是為了提供良好的學習環境給我，爸媽雖沒有頂尖的學歷，但他們相當注重我的品德教育，爸爸常常藉由空閒時間和我分享以前生活貧困時的生活的趣事，培養我從小就要有分辨是非對錯的能力，懂得腳踏實地、認真踏實的處事態度，要求我為人處事要有同理心，更希望我在長成後運用所學對社會盡一份心力，父母給了我快樂成長的家庭生活，同時孕育出我能積極正向的人生觀，讓我在求學的路上一直秉持這般的信念，努力學習。從小我就喜歡自己動手做東西，也常接觸邏輯推導的問題，國中一年級時生涯輔導老師對我們做了一系列測試，我在數學及邏輯領域皆拿到全班最高分，這個測試也加深了我對自己的邏輯以及數理科的自信。國中的理化老師，他常常用具有豐富邏輯思考以及幽默的方式讓我們在短短幾節課了解課程內容，然後利用課餘時間分享他以前玩電玩遊戲經驗，他的教導下不僅使我在數理方面的成績一直維持班上的前三名，也讓我從起初對電玩興趣轉而對資訊方面產生深深的好奇。另一方面，在國三即將升學的階段受到姨丈的影響，姨丈常將業界耕作的經驗分享給我，讓我也想成為一名工程師，學會程式語言以及各種電腦技能，希望能像姨丈一樣在這個資訊日新月異的世代裡，能符應潮流，這也是我後來選擇資訊這方面的原因。";

  @override
  Widget build(BuildContext context) {

    player.play(AssetSource("Free_Test_Data_1MB_MP3.mp3"));

    return SingleChildScrollView(
      child: Column(
        children:<Widget>[
          //先放個標題
          Padding(padding: EdgeInsets.fromLTRB(20, 30, 20, 20),
            child: Text("Who am I?",
                style: TextStyle(fontSize:24,
                  fontWeight:FontWeight.bold,)),
          ),
          //文字自傳部份
          Container(
            padding: EdgeInsets.all(20),
            margin: EdgeInsets.fromLTRB(30, 0, 30, 50),
            decoration: BoxDecoration(
              border: Border.all(color: Colors.black, width: 3),
              borderRadius: BorderRadius.circular(8),
              boxShadow: [ BoxShadow(color: Colors.amberAccent,
                  offset: Offset(6, 6)),
              ],),
            child:Text(s1,
              style: TextStyle(fontSize: 20),),
          ),

          //放一張照片
          Container(
            color: Colors.redAccent,
            child: Image.asset('images/f1.jpg'),
            height: 200,
            width: 200,
          ),
          SizedBox(height: 30,),

          //一列放兩個圖
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Container(
                width: 150,
                height: 150,
                decoration: BoxDecoration(
                  border: Border.all(
                    width: 2,
                    color: Colors.purple,

                    style: BorderStyle.solid,
                  ),
                  borderRadius: BorderRadius.circular(30),
                  image: DecorationImage(
                    image: AssetImage('images/f2.jpg'),
                    fit: BoxFit.cover ,
                  ),
                  color: Colors.white,
                ),
              ),
              Container(
                width: 150,
                height: 150,
                decoration: BoxDecoration(
                  border: Border.all(
                    width: 2,
                    color: Colors.purple,
                    style: BorderStyle.solid,
                  ),
                  borderRadius: BorderRadius.circular(30),
                  image: DecorationImage(
                    image: AssetImage('images/f3.jpg'),
                    fit: BoxFit.cover ,
                  ),
                  color: Colors.white,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class screen2 extends StatelessWidget {
  @override
  final String s2='個人興趣-我的興趣是自己動手做東西，在學校的創客教育影響下，我開始會思考該如何運用程式設計的能力配合各種感測器及開發版來解決日常生活中的問題。除了動手做東西外，我還喜歡寫程式，能夠解決複雜的邏輯問題帶給我莫大的成就感。我很清楚未來是資訊的時代，物聯網與機器人將會是潮流並與程式設計都脫不了關係，而以上技術大都需要C語言這種中低階的程式語言支持，所以當大家都討厭寫傳統C語言的同時，我反而想要更加精進的去學習，在老師的教導下，每天解題，透過解題去了解更多演算法以及計算機的知識，也希望可以多透過解題的演算法中激發出可以結合在創客精神上的作品。';
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
          children:<Widget>[
      //先放個標題
      Padding(padding: EdgeInsets.fromLTRB(20, 30, 20, 20),
      child: Text("學習歷程",
          style: TextStyle(fontSize:24,
            fontWeight:FontWeight.bold,)),
    ),
    //
    Container(
    padding: EdgeInsets.all(20),
    margin: EdgeInsets.fromLTRB(30, 0, 30, 50),
    decoration: BoxDecoration(
    border: Border.all(color: Colors.black, width: 3),
    borderRadius: BorderRadius.circular(8),
    boxShadow: [ BoxShadow(color: Colors.white,
    offset: Offset(6, 6)),
    ],),
    child:Text(s2,
    style: TextStyle(fontSize: 20),),
    ),
    ]
    ),

    );
  }
}

class screen3 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      child:Column(
        children: [
          //有多種排版方式, 此處以最直覺的方式將每一列放文字內容
          SizedBox(height: 10,),
          Row( mainAxisAlignment: MainAxisAlignment.start,
            children: [Text("大二時期"),],),
          SizedBox(height: 10,),
          Row(mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Container(
                height: 100,
                width: 200,
                child: ListView(
                  children: [
                    //條列式參考
                    Text('1. 練習閱讀原文的專業書籍加強外語能力'),
                    Text('2. 提升問題解決能力'),
                    Text('3. 深入研究資訊安全及相關專業知識'),
                    Text('4. 深化程式語言及邏輯思維能力'),
                  ],
                ),
              ),
            ],),
          SizedBox(height: 10,),
          Row( mainAxisAlignment: MainAxisAlignment.start,
            children: [Text("大三時期"),],),
          SizedBox(height: 10,),
          Row(mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Container(
                height: 100,
                width: 200,
                child: ListView(
                  children: [
                    //條列式參考
                    Text('1. 強化研發能力'),
                    Text('2. 深入專研演算模擬方法及研究方法'),
                    Text('3. 學習組織團隊合作與領導力'),
                    Text('4. 利用各項累積經驗製作專題'),
                  ],
                ),
              ),
            ],),
          SizedBox(height: 10,),
          Row(mainAxisAlignment: MainAxisAlignment.start,
            children: [Text("大四時期"),],),
          SizedBox(height: 10,),
          Row(mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Container(
                height: 100,
                width: 200,
                child: ListView(
                  children: [
                    //條列式參考
                    Text('1. 準備研究所考試'),
                  ],
                ),
              ),
            ],),
        ],
      ),);
  }
}

class screen4 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(child:Text(''),);
  }
}
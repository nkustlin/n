import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';

class screen1 extends StatelessWidget {

  final String s1='說到資訊安全，你會想到什麼呢？我們需要淘汰舊有的觀念，資訊安全可以說是有著成為常識的趨勢。愛默生曾經認為，只有智者視人生如節目。帶著這句話，我們還要更加慎重的審視這個問題。荀況曾經提過，賢能不待次而舉。這句話改變了我的人生。如果別人做得到，那我也可以做到。資訊安全改變了我的命運。我以為我了解資訊安全，但我真的了解資訊安全嗎？仔細想想，我對資訊安全的理解只是皮毛而已。波特講過一句值得人反覆尋思的話，人生是由哽咽哭泣及微笑所組成的一段過程，而其中更大的部分是哽咽。他會這麼說是有理由的。我們不得不相信，對資訊安全進行深入研究，在現今時代已經無法避免了。資訊安全勢必能夠左右未來。我們一般認為，抓住了問題的關鍵，其他一切則會迎刃而解。我們普遍認為，若能理解透徹核心原理，對其就有了一定的了解程度。把資訊安全輕鬆帶過，顯然並不適合。這必定是個前衛大膽的想法。培根深信，無論你怎樣地表示憤怒，都不要做出任何無法挽回的事來。這句話決定了一切。若能夠欣賞到資訊安全的美，相信我們一定會對資訊安全改觀。';

  @override
  Widget build(BuildContext context) {

    final player=AudioPlayer();
    player.play(AssetSource("assets/Free_Test_Data_1MB_MP3.mp3"));

    return SingleChildScrollView(
      child: Column(
        children:<Widget>[
          Padding(padding: EdgeInsets.fromLTRB(20, 30, 20, 20),
                  child: Text("Who am I",
                              style: TextStyle(fontSize:24,
                                               fontWeight:FontWeight.bold,)),
          ),
          Container(
            padding: EdgeInsets.all(20),
            margin: EdgeInsets.fromLTRB(30, 0, 30, 50),
            decoration: BoxDecoration(
                        border: Border.all(color: Colors.black, width: 3),
                        borderRadius: BorderRadius.circular(8),
                        boxShadow: [ BoxShadow(color: Colors.amberAccent,
                                               offset: Offset(6, 6)),
                        ],),
            child:Text(s1,
                       style: TextStyle(fontSize: 20),),
            ),

           Container(
             color: Colors.redAccent,
             child: Image.asset('images/f1.jpg'),
             height: 200,
             width: 200,
           ),
          SizedBox(height: 30,),

          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Container(
                width: 150,
                height: 150,
                decoration: BoxDecoration(
                  border: Border.all(
                    width: 2,
                    color: Colors.purple,
                    style: BorderStyle.solid,
                  ),
                  borderRadius: BorderRadius.circular(30),
                  image: DecorationImage(
                            image: AssetImage('images/f2.jpg'),
                            fit: BoxFit.cover ,
                  ),
                  color: Colors.white,
                ),
              ),
              Container(
                width: 150,
                height: 150,
                decoration: BoxDecoration(
                  border: Border.all(
                    width: 2,
                    color: Colors.purple,
                    style: BorderStyle.solid,
                  ),
                  borderRadius: BorderRadius.circular(30),
                  image: DecorationImage(
                    image: AssetImage('images/f3.jpg'),
                    fit: BoxFit.cover ,
                  ),
                  color: Colors.white,
                ),
              ),

            ],
          ),
        ],
      ),
    );
  }
}